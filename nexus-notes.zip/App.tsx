import React, { useState, useEffect, useCallback } from 'react';
import { 
  Book, 
  Plus, 
  ChevronRight, 
  Folder, 
  FileText, 
  ArrowLeft, 
  Trash2, 
  Sparkles, 
  Save, 
  Brain,
  MoreVertical,
  Pencil,
  GraduationCap
} from 'lucide-react';
import { Button } from './components/Button';
import { Modal } from './components/Modal';
import { Subject, Chapter, Note, ViewState, AIActionType } from './types';
import { generateAIResponse } from './services/geminiService';
import { getRandomColor } from './constants';

function App() {
  // --- State Management ---
  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('nexus_notes_data');
    return saved ? JSON.parse(saved) : [];
  });

  const [viewState, setViewState] = useState<ViewState>('SUBJECTS');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [selectedChapterId, setSelectedChapterId] = useState<string | null>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);

  // Modal States
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [isChapterModalOpen, setIsChapterModalOpen] = useState(false);
  const [newSubjectTitle, setNewSubjectTitle] = useState('');
  const [newSubjectCode, setNewSubjectCode] = useState('');
  const [newChapterTitle, setNewChapterTitle] = useState('');

  // Editor & AI State
  const [editorContent, setEditorContent] = useState('');
  const [editorTitle, setEditorTitle] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<string | null>(null);
  const [aiMode, setAiMode] = useState<AIActionType | null>(null);

  // --- Effects ---
  useEffect(() => {
    localStorage.setItem('nexus_notes_data', JSON.stringify(subjects));
  }, [subjects]);

  // --- Helpers ---
  const getSelectedSubject = () => subjects.find(s => s.id === selectedSubjectId);
  const getSelectedChapter = () => getSelectedSubject()?.chapters.find(c => c.id === selectedChapterId);
  const getSelectedNote = () => getSelectedChapter()?.notes.find(n => n.id === selectedNoteId);

  // --- CRUD Operations ---
  
  const handleCreateSubject = () => {
    if (!newSubjectTitle.trim()) return;
    const newSubject: Subject = {
      id: crypto.randomUUID(),
      title: newSubjectTitle,
      code: newSubjectCode,
      color: getRandomColor(),
      chapters: [],
      createdAt: Date.now()
    };
    setSubjects([...subjects, newSubject]);
    setNewSubjectTitle('');
    setNewSubjectCode('');
    setIsSubjectModalOpen(false);
  };

  const handleDeleteSubject = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (confirm('Are you sure? All chapters and notes in this subject will be lost.')) {
      setSubjects(subjects.filter(s => s.id !== id));
    }
  };

  const handleCreateChapter = () => {
    if (!newChapterTitle.trim() || !selectedSubjectId) return;
    
    setSubjects(prevSubjects => prevSubjects.map(sub => {
      if (sub.id === selectedSubjectId) {
        return {
          ...sub,
          chapters: [...sub.chapters, {
            id: crypto.randomUUID(),
            title: newChapterTitle,
            notes: [],
            createdAt: Date.now()
          }]
        };
      }
      return sub;
    }));
    
    setNewChapterTitle('');
    setIsChapterModalOpen(false);
  };

  const handleDeleteChapter = (e: React.MouseEvent, chapterId: string) => {
    e.stopPropagation();
    if (!selectedSubjectId) return;
    if (confirm('Delete this chapter and all its notes?')) {
      setSubjects(prev => prev.map(s => {
        if (s.id === selectedSubjectId) {
          return { ...s, chapters: s.chapters.filter(c => c.id !== chapterId) };
        }
        return s;
      }));
    }
  };

  const handleCreateNote = () => {
    if (!selectedSubjectId || !selectedChapterId) return;
    
    const newNote: Note = {
      id: crypto.randomUUID(),
      title: 'Untitled Note',
      content: '',
      createdAt: Date.now(),
      lastModified: Date.now()
    };

    setSubjects(prev => prev.map(s => {
      if (s.id === selectedSubjectId) {
        return {
          ...s,
          chapters: s.chapters.map(c => {
            if (c.id === selectedChapterId) {
              return { ...c, notes: [...c.notes, newNote] };
            }
            return c;
          })
        };
      }
      return s;
    }));

    // Immediately open the new note
    setSelectedNoteId(newNote.id);
    setEditorTitle(newNote.title);
    setEditorContent(newNote.content);
    setAiResult(null);
    setViewState('NOTES');
  };

  const handleDeleteNote = (e: React.MouseEvent, noteId: string) => {
    e.stopPropagation();
    if (!selectedSubjectId || !selectedChapterId) return;
    if (confirm('Delete this note?')) {
      setSubjects(prev => prev.map(s => {
        if (s.id === selectedSubjectId) {
          return {
            ...s,
            chapters: s.chapters.map(c => {
              if (c.id === selectedChapterId) {
                return { ...c, notes: c.notes.filter(n => n.id !== noteId) };
              }
              return c;
            })
          };
        }
        return s;
      }));
    }
  };

  const handleSaveNote = () => {
    if (!selectedSubjectId || !selectedChapterId || !selectedNoteId) return;

    setSubjects(prev => prev.map(s => {
      if (s.id === selectedSubjectId) {
        return {
          ...s,
          chapters: s.chapters.map(c => {
            if (c.id === selectedChapterId) {
              return {
                ...c,
                notes: c.notes.map(n => {
                  if (n.id === selectedNoteId) {
                    return { ...n, title: editorTitle, content: editorContent, lastModified: Date.now() };
                  }
                  return n;
                })
              };
            }
            return c;
          })
        };
      }
      return s;
    }));
  };

  // --- AI Operations ---
  const handleAiAction = async (action: AIActionType) => {
    if (!editorContent.trim()) return;
    
    setIsAiLoading(true);
    setAiMode(action);
    setAiResult(null);
    
    const result = await generateAIResponse(editorContent, action);
    
    setAiResult(result);
    setIsAiLoading(false);
  };

  // --- Navigation Helpers ---
  const navigateToSubjects = () => {
    setViewState('SUBJECTS');
    setSelectedSubjectId(null);
    setSelectedChapterId(null);
    setSelectedNoteId(null);
  };

  const navigateToChapters = (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    setViewState('CHAPTERS');
  };

  const navigateToNotes = (chapterId: string) => {
    setSelectedChapterId(chapterId);
    // We stay in CHAPTERS view but show the list.
    // However, if we click a note, we go to Note Editor.
  };

  const openNote = (note: Note) => {
    setSelectedNoteId(note.id);
    setEditorTitle(note.title);
    setEditorContent(note.content);
    setAiResult(null); // Reset AI result when opening a new note
    setViewState('NOTES');
  };

  // --- Render Views ---

  // 1. Subjects Grid
  const renderSubjectsView = () => (
    <div className="p-6 max-w-7xl mx-auto animate-fade-in">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Subjects</h1>
          <p className="text-gray-500 mt-1">Manage your course materials and notes</p>
        </div>
        <Button onClick={() => setIsSubjectModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Subject
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects.map(subject => (
          <div 
            key={subject.id}
            onClick={() => navigateToChapters(subject.id)}
            className="group relative bg-white rounded-xl shadow-sm border border-gray-200 hover:shadow-lg hover:border-indigo-200 transition-all cursor-pointer overflow-hidden"
          >
            <div className={`h-3 w-full ${subject.color}`} />
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div className={`p-3 rounded-lg ${subject.color} bg-opacity-10 text-${subject.color.replace('bg-', '')}`}>
                  <Book className="w-6 h-6" />
                </div>
                <button 
                  onClick={(e) => handleDeleteSubject(e, subject.id)}
                  className="text-gray-400 hover:text-red-500 p-1 rounded-full hover:bg-gray-100 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              
              <h3 className="mt-4 text-xl font-bold text-gray-900">{subject.title}</h3>
              {subject.code && <p className="text-sm font-medium text-gray-500 mb-2">{subject.code}</p>}
              
              <div className="mt-4 flex items-center text-sm text-gray-500">
                <Folder className="w-4 h-4 mr-1.5" />
                {subject.chapters.length} Chapters
              </div>
            </div>
          </div>
        ))}

        {subjects.length === 0 && (
          <div className="col-span-full flex flex-col items-center justify-center py-20 bg-white rounded-xl border-2 border-dashed border-gray-300">
            <div className="p-4 bg-indigo-50 rounded-full mb-4">
              <GraduationCap className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900">No subjects yet</h3>
            <p className="text-gray-500 mb-4">Get started by creating your first subject</p>
            <Button onClick={() => setIsSubjectModalOpen(true)} variant="secondary">
              Create Subject
            </Button>
          </div>
        )}
      </div>
    </div>
  );

  // 2. Chapters List
  const renderChaptersView = () => {
    const subject = getSelectedSubject();
    if (!subject) return null;

    return (
      <div className="p-6 max-w-7xl mx-auto h-[calc(100vh-80px)]">
        {/* Header */}
        <div className="flex items-center mb-8 text-sm">
          <button onClick={navigateToSubjects} className="text-gray-500 hover:text-gray-900 flex items-center">
            <ArrowLeft className="w-4 h-4 mr-1" /> Subjects
          </button>
          <ChevronRight className="w-4 h-4 text-gray-400 mx-2" />
          <span className="font-semibold text-gray-900">{subject.title}</span>
        </div>

        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <span className={`w-3 h-8 ${subject.color} rounded-full mr-3`}></span>
            {subject.title} Chapters
          </h2>
          <Button onClick={() => setIsChapterModalOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Chapter
          </Button>
        </div>

        {/* Chapters Grid/List */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
           {subject.chapters.map(chapter => (
             <div key={chapter.id} className="bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col h-96">
                <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-xl">
                   <h3 className="font-bold text-gray-800 truncate pr-2" title={chapter.title}>{chapter.title}</h3>
                   <div className="flex items-center space-x-2">
                     <button 
                        onClick={(e) => handleDeleteChapter(e, chapter.id)}
                        className="text-gray-400 hover:text-red-500 p-1"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                   </div>
                </div>
                
                {/* Notes List inside Chapter Card */}
                <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-white">
                  {chapter.notes.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-gray-400">
                      <FileText className="w-8 h-8 mb-2 opacity-50" />
                      <span className="text-sm">No notes yet</span>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {chapter.notes.map(note => (
                        <div 
                          key={note.id}
                          onClick={() => {
                            setSelectedChapterId(chapter.id);
                            openNote(note);
                          }}
                          className="p-3 hover:bg-indigo-50 rounded-lg cursor-pointer border border-transparent hover:border-indigo-100 group transition-all"
                        >
                          <div className="flex items-center justify-between">
                             <div className="flex items-center overflow-hidden">
                                <FileText className="w-4 h-4 text-indigo-500 mr-2 flex-shrink-0" />
                                <span className="text-sm font-medium text-gray-700 truncate">{note.title}</span>
                             </div>
                             <span className="text-xs text-gray-400 group-hover:text-indigo-400">
                               {new Date(note.lastModified).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                             </span>
                          </div>
                          <p className="text-xs text-gray-500 mt-1 truncate pl-6">
                            {note.content.substring(0, 40) || "Empty note..."}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="p-3 border-t border-gray-100 bg-gray-50 rounded-b-xl">
                  <button 
                    onClick={() => {
                      setSelectedChapterId(chapter.id);
                      handleCreateNote();
                    }}
                    className="w-full py-2 text-sm text-indigo-600 font-medium hover:bg-indigo-50 rounded-lg transition-colors flex items-center justify-center border border-indigo-200 bg-white"
                  >
                    <Plus className="w-4 h-4 mr-1" /> Add Note
                  </button>
                </div>
             </div>
           ))}

           {subject.chapters.length === 0 && (
             <div className="col-span-full py-16 text-center bg-white rounded-xl border border-gray-200">
                <Folder className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">Create a chapter to start adding notes.</p>
             </div>
           )}
        </div>
      </div>
    );
  };

  // 3. Note Editor View
  const renderNoteEditor = () => {
    const subject = getSelectedSubject();
    const chapter = getSelectedChapter();
    // Use local state if we are editing, but we need context for breadcrumbs
    
    if (!subject || !chapter) return null;

    return (
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Editor Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex justify-between items-center shadow-sm z-10">
          <div className="flex items-center space-x-4">
             <button 
               onClick={() => setViewState('CHAPTERS')} 
               className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors"
             >
               <ArrowLeft className="w-5 h-5" />
             </button>
             <div className="flex flex-col">
               <div className="flex items-center text-xs text-gray-500 space-x-2">
                 <span>{subject.title}</span>
                 <ChevronRight className="w-3 h-3" />
                 <span>{chapter.title}</span>
               </div>
               <input 
                 type="text"
                 value={editorTitle}
                 onChange={(e) => setEditorTitle(e.target.value)}
                 className="text-lg font-bold text-gray-900 border-none focus:ring-0 p-0 hover:bg-gray-50 rounded px-1 -ml-1 w-64 md:w-96"
                 placeholder="Note Title"
               />
             </div>
          </div>
          
          <div className="flex items-center space-x-3">
             <span className="text-xs text-gray-400 hidden sm:inline">
               {editorContent.length} chars
             </span>
             <Button onClick={handleSaveNote} size="sm">
               <Save className="w-4 h-4 mr-2" />
               Save
             </Button>
          </div>
        </header>

        {/* Main Content Area: Split View */}
        <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
          
          {/* Editor Input */}
          <div className={`flex-1 flex flex-col h-full bg-white relative ${aiResult ? 'lg:w-1/2 border-r border-gray-200' : 'w-full'}`}>
            <textarea
              value={editorContent}
              onChange={(e) => setEditorContent(e.target.value)}
              placeholder="Start typing your notes here..."
              className="flex-1 w-full p-8 resize-none focus:outline-none text-gray-800 leading-relaxed custom-scrollbar text-lg font-mono bg-white"
            />
            
            {/* AI Toolbar floating at bottom */}
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-white shadow-lg border border-gray-200 rounded-full px-2 py-1 flex items-center space-x-1 z-10">
              <span className="pl-3 pr-2 text-xs font-bold text-indigo-600 flex items-center uppercase tracking-wider">
                <Sparkles className="w-3 h-3 mr-1" /> AI Tools
              </span>
              <div className="h-4 w-px bg-gray-300 mx-1"></div>
              <button 
                onClick={() => handleAiAction(AIActionType.SUMMARIZE)}
                disabled={isAiLoading}
                className="p-2 hover:bg-indigo-50 rounded-full text-gray-600 hover:text-indigo-600 transition-colors"
                title="Summarize"
              >
                <FileText className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleAiAction(AIActionType.QUIZ)}
                disabled={isAiLoading}
                className="p-2 hover:bg-indigo-50 rounded-full text-gray-600 hover:text-indigo-600 transition-colors"
                title="Generate Quiz"
              >
                <Brain className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleAiAction(AIActionType.ELABORATE)}
                disabled={isAiLoading}
                className="p-2 hover:bg-indigo-50 rounded-full text-gray-600 hover:text-indigo-600 transition-colors"
                title="Elaborate"
              >
                <Book className="w-4 h-4" />
              </button>
               <button 
                onClick={() => handleAiAction(AIActionType.FIX_GRAMMAR)}
                disabled={isAiLoading}
                className="p-2 hover:bg-indigo-50 rounded-full text-gray-600 hover:text-indigo-600 transition-colors"
                title="Fix Grammar"
              >
                <Pencil className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* AI Result Panel */}
          {aiResult && (
            <div className="lg:w-1/2 h-1/2 lg:h-full bg-indigo-50 flex flex-col border-t lg:border-t-0 border-gray-200 animate-slide-in-right">
              <div className="flex items-center justify-between p-4 border-b border-indigo-100 bg-white">
                <div className="flex items-center text-indigo-700 font-semibold">
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Assistant: {aiMode === AIActionType.SUMMARIZE ? 'Summary' : aiMode === AIActionType.QUIZ ? 'Quiz' : 'Insight'}
                </div>
                <button onClick={() => setAiResult(null)} className="text-gray-400 hover:text-gray-600">
                   <XIcon className="w-5 h-5" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                <div className="prose prose-indigo max-w-none">
                  <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
                    {aiResult}
                  </div>
                </div>
              </div>
              <div className="p-4 border-t border-indigo-100 bg-white flex justify-end">
                <Button 
                  size="sm" 
                  variant="secondary"
                  onClick={() => {
                    setEditorContent(prev => prev + "\n\n--- AI Generated ---\n" + aiResult);
                    setAiResult(null);
                  }}
                >
                  Append to Note
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Helper component for X icon locally
  const XIcon = ({className}:{className?:string}) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      
      {viewState !== 'NOTES' && (
        <nav className="bg-white border-b border-gray-200 px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between sticky top-0 z-20">
          <div className="flex items-center">
            <div className="bg-indigo-600 p-2 rounded-lg mr-3">
              <Book className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">
              Nexus Notes
            </span>
          </div>
          <div className="text-sm text-gray-500">
            {subjects.reduce((acc, s) => acc + s.chapters.reduce((cAcc, c) => cAcc + c.notes.length, 0), 0)} Total Notes
          </div>
        </nav>
      )}

      {/* Main Content Router */}
      <main>
        {viewState === 'SUBJECTS' && renderSubjectsView()}
        {viewState === 'CHAPTERS' && renderChaptersView()}
        {viewState === 'NOTES' && renderNoteEditor()}
      </main>

      {/* Modals */}
      <Modal 
        isOpen={isSubjectModalOpen} 
        onClose={() => setIsSubjectModalOpen(false)} 
        title="Create New Subject"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Subject Title</label>
            <input 
              type="text" 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              placeholder="e.g. Computer Science"
              value={newSubjectTitle}
              onChange={(e) => setNewSubjectTitle(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Course Code (Optional)</label>
            <input 
              type="text" 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              placeholder="e.g. CS101"
              value={newSubjectCode}
              onChange={(e) => setNewSubjectCode(e.target.value)}
            />
          </div>
          <div className="flex justify-end pt-4">
             <Button variant="ghost" onClick={() => setIsSubjectModalOpen(false)} className="mr-2">Cancel</Button>
             <Button onClick={handleCreateSubject}>Create Subject</Button>
          </div>
        </div>
      </Modal>

      <Modal 
        isOpen={isChapterModalOpen} 
        onClose={() => setIsChapterModalOpen(false)} 
        title="Create New Chapter"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Chapter Title</label>
            <input 
              type="text" 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              placeholder="e.g. Week 1: Introduction"
              value={newChapterTitle}
              onChange={(e) => setNewChapterTitle(e.target.value)}
            />
          </div>
          <div className="flex justify-end pt-4">
             <Button variant="ghost" onClick={() => setIsChapterModalOpen(false)} className="mr-2">Cancel</Button>
             <Button onClick={handleCreateChapter}>Create Chapter</Button>
          </div>
        </div>
      </Modal>

    </div>
  );
}

export default App;